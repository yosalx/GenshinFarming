# Genshin Farming

### Farm Simulation Role-Playing Game made to fulfill the final major task of IF2121 'Computational Logic' Class at Institut Teknologi Bandung.

### Synopsis :
#### Claire has been scammed by a client who magically disappeared without paying for a project she worked so hard on.  In addition to being a victim of fraud, Claire is also in debt of 20000 gold which needs to be repaid within a year. Therefore, Claire decided to return to her hometown and continue her grandfather's farming business to pay off her debt.

## Class 03 Group 03 Genshin Farming 

| NIM      | NAME                     |
|----------|--------------------------|
| 13520114 | Kevin Roni               |
| 13520141 | Yoseph Alexander Siregar |
| 13520155 | Jundan Haris             |
| 13520156 | Dimas Faidh Muzaki       |
| 13520158 | Azmi Alfatih Shalahuddin |

## Directory

## How to Run
1. Prolog installed
2. GNU Prolog installed
3. consult start.pl on gnu prolog
4. run command sdebug.
5. run command [start].
6. run command start.
7. enjoy the game
