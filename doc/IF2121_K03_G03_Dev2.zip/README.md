# GenshinFarming
Panen tubes
